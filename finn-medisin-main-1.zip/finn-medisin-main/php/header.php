<?php
 
 echo '
 <header>
      <div class="logo_nav_header">
        <img
          class="image-logo"
          src="Logo/Logo-1-removebg-preview.png"
          alt="Logo"
          width="100"
          height="100"
        />
        <nav>
          <ul>
            <li class="nav-placement">
              <a href="./index.php" class="nav-horizontal">Hjem</a>
            </li>
            <li class="nav-placement">
              <a href="omoss.php" class="nav-horizontal">Om oss</a>
            </li>
            <li class="nav-placement">
              <a href="logginn.html" class="nav-horizontal">Logg inn</a>
            </li>
             <li class="nav-placement">
              <a href="logginn.html" class="nav-horizontal">Ny Konto</a>
            </li>
          </ul>
        </nav>
      </div>
    </header>
  ';

?>